/*#include <iostream>
#include <string>
using namespace std;




class Inventory
{
  public:
      struct Items
      {
        string name;
        int id;
        int slot;
      }item[20];
      void AddItem(string Name, int Id)
      {
        item[islot].name = Name;
        item[islot].price = Price;
        item[islot].lvlreq = Lvlreq;e
        islot++;
      }
}

//ITEM STRUCTS//
//For item types, 1 is consumable/usable, 2 is wearable
// would have other categories such as quest items, vendor items, useless, but for the purpose of this program, there are only 2 categories.

struct item
{
  string name;
  int id;
}




// * * * * * * * * * * * *** * * * * * * * * * *
// alternative way
// * * * * * * * * * * * *** * * * * * * * * * 


template<typename Item_Type, unsigned int capacity>
class Container
{
  public:
      Container(void)
      {
        
      }
      //will return true if item was added, false if not
      bool add(const Item_Type& item)
      {
        if(capactiy > items.size())
        //should give custom behavior
        {
          return true;
        }
      return false;
      }

unsigned int getCapactiy(void) const
{
  return capactiy;
}

unsigned int getSize(void) const
{
  return items.size();
}

//possible throw
const Item_Type& get(unsigned int index) const
{
  return items.at(index);
}

//true if index removed
bool remove(unsigned int index)
{
  if(index < items.size())
  {
    items.erase(items.begin() + index);
    return true;
  }
  return false;
}

~Container(void)
{
  
}

private: vector<Item_Type> items;
};

class MyItem
{
};

int main()
{
  Container<MyItem, 30> inventory; //container to hold 30 items
  inventory.add(MyItem());
  const MyItem& item = inventory.get(0);
  inventory.remove(0);
  return 0;
}*/