/*#include <iostream>
#include <stdlib.h>
#include <string>

using namespace std;
//class system

class Enemy
{
  public: 
  enemy();
    
  //local attributes
  int hp;
  int maxHP;
  int stamina;
  int totalStamina;
  int level;
  int xp;
  int obedienceLvl;
  int posX;
  int posY;
  int requiredXP;
  bool isAlive();

  //strings for player
  string playerName;
  string playerClass;
  

  //functions for player
  void useHealthPack();
  void useEnergyPack();
  void checkStats();
  void setPlayerClass();
  void setPlayerName();
  void checkInventory();
  
  
  //use a health pack, if one exists in inventory
  void useHealthPack()
  {
    if 
  }
  //Class Data
  
  //Melee
  
  //Space Magic
  
  //Ranger
  
  //fighting functions and variables!
    
  };

*/