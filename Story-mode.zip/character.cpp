/*#include <iostream>
#include <stdlib.h>
#include <string>
#include <algorithm>
#ifdef CHARACTER_H
#define CHARACTER_H
#endif

using namespace std;

//starting values for char
character::character()
{
  health = 100;
  totalHealth = 100;
  stamina = 50;
  totalStamina = 50;
  level = 1;
  experience = 0;
  requiredXP = 50;
}

// 
void character::setPlayerName()
{
  cout << "What is your name?" << endl;
  cout << ">> ";
  getline (cin, playerName);
  setPlayerClass();
}

//function to let player choose class, will be initialized by setPlayerName
void character::setPlayerClass()
{
  bool validClass = false;
  //change later to something more fitting
  cout << playerName << ", what is your class?" << endl;
  while (validClass)
  {
    //note: all weapons available to all classes, this will likely have something to do with bonuses and attribute points...
    
    cout << "> Space Magic" << endl;
    //
    cout << "> Ranger" << endl;
    //
    cout << "> Melee" << endl;
    //
    cout << " " << endl;
    
    getline(cin, playerClass);
transform(playerClass.begin(), playerClass.end(), playerClass.begin(), toupper);
    if ((playerClass == "SPACE MAGIC") || (playerClass == "RANGER") || (playerClass == "MELEE"))
    {
      validClass = true;
    }
    else
    {
      cout << "Please pick a valid class." << endl;
    }
  }
}

//char uses energy (stamina) pack, will eliminate one from total energy packs
void character::useEnergyPack()
{
  
}

//char uses health pack, will eliminate one from total health packs
void character::useHealthPack()
{
  
}

//checks to see if player is alive, will return true if ye
bool character::isAlive()
{
  if (health <= 0)
  {
    return false;
  }
  else 
  {
    return true;
  }
}
*/